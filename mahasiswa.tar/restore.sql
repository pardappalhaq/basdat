--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 18.6
-- Dumped by pg_dump version 18.6

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE mahasiswa;
--
-- Name: mahasiswa; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE mahasiswa WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'English_Indonesia.1252';


ALTER DATABASE mahasiswa OWNER TO postgres;

\unrestrict (null)
\connect mahasiswa
\restrict (null)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: tblhasilbelajar; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tblhasilbelajar (
    idhasilbelajar integer NOT NULL,
    nrp character varying(10),
    kodekuliah character varying(10),
    nilaiuts integer,
    nilaiuas integer
);


ALTER TABLE public.tblhasilbelajar OWNER TO postgres;

--
-- Name: tblkuliah; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tblkuliah (
    kodekuliah character varying(10) NOT NULL,
    namakuliah character varying(100),
    sks integer,
    semester integer
);


ALTER TABLE public.tblkuliah OWNER TO postgres;

--
-- Name: tblmahasiswa; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tblmahasiswa (
    nrp character varying(10) NOT NULL,
    nama character varying(50),
    kotaasal character varying(50),
    anakke integer,
    tmplahir character varying(50),
    tgllahir date,
    agama character varying(20),
    hobi integer
);


ALTER TABLE public.tblmahasiswa OWNER TO postgres;

--
-- Data for Name: tblhasilbelajar; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tblhasilbelajar (idhasilbelajar, nrp, kodekuliah, nilaiuts, nilaiuas) FROM stdin;
\.
COPY public.tblhasilbelajar (idhasilbelajar, nrp, kodekuliah, nilaiuts, nilaiuas) FROM '$$PATH$$/5020.dat';

--
-- Data for Name: tblkuliah; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tblkuliah (kodekuliah, namakuliah, sks, semester) FROM stdin;
\.
COPY public.tblkuliah (kodekuliah, namakuliah, sks, semester) FROM '$$PATH$$/5019.dat';

--
-- Data for Name: tblmahasiswa; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tblmahasiswa (nrp, nama, kotaasal, anakke, tmplahir, tgllahir, agama, hobi) FROM stdin;
\.
COPY public.tblmahasiswa (nrp, nama, kotaasal, anakke, tmplahir, tgllahir, agama, hobi) FROM '$$PATH$$/5018.dat';

--
-- Name: tblhasilbelajar tblhasilbelajar_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tblhasilbelajar
    ADD CONSTRAINT tblhasilbelajar_pkey PRIMARY KEY (idhasilbelajar);


--
-- Name: tblkuliah tblkuliah_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tblkuliah
    ADD CONSTRAINT tblkuliah_pkey PRIMARY KEY (kodekuliah);


--
-- Name: tblmahasiswa tblmahasiswa_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tblmahasiswa
    ADD CONSTRAINT tblmahasiswa_pkey PRIMARY KEY (nrp);


--
-- Name: tblhasilbelajar tblhasilbelajar_kodekuliah_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tblhasilbelajar
    ADD CONSTRAINT tblhasilbelajar_kodekuliah_fkey FOREIGN KEY (kodekuliah) REFERENCES public.tblkuliah(kodekuliah) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tblhasilbelajar tblhasilbelajar_nrp_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tblhasilbelajar
    ADD CONSTRAINT tblhasilbelajar_nrp_fkey FOREIGN KEY (nrp) REFERENCES public.tblmahasiswa(nrp) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

