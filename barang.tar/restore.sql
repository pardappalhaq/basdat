--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 18.6
-- Dumped by pg_dump version 18.6

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE barang;
--
-- Name: barang; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE barang WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'English_Indonesia.1252';


ALTER DATABASE barang OWNER TO postgres;

\unrestrict (null)
\connect barang
\restrict (null)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: tblbarang; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tblbarang (
    kodebarang character varying(4) NOT NULL,
    namabarang character varying(20),
    satuan character varying(1),
    stock integer,
    hargasatuan numeric(15,2)
);


ALTER TABLE public.tblbarang OWNER TO postgres;

--
-- Name: tblpemasok; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tblpemasok (
    kodepemasok character varying(4) NOT NULL,
    nama character varying(50),
    alamat character varying(100),
    telepon character varying(20)
);


ALTER TABLE public.tblpemasok OWNER TO postgres;

--
-- Name: tbltransaksi; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tbltransaksi (
    notransaksi character varying(4) NOT NULL,
    tanggal date,
    kodebarang character varying(4),
    kodepemasok character varying(4),
    jumlah integer,
    harga numeric(15,2)
);


ALTER TABLE public.tbltransaksi OWNER TO postgres;

--
-- Data for Name: tblbarang; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tblbarang (kodebarang, namabarang, satuan, stock, hargasatuan) FROM stdin;
\.
COPY public.tblbarang (kodebarang, namabarang, satuan, stock, hargasatuan) FROM '$$PATH$$/5018.dat';

--
-- Data for Name: tblpemasok; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tblpemasok (kodepemasok, nama, alamat, telepon) FROM stdin;
\.
COPY public.tblpemasok (kodepemasok, nama, alamat, telepon) FROM '$$PATH$$/5019.dat';

--
-- Data for Name: tbltransaksi; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tbltransaksi (notransaksi, tanggal, kodebarang, kodepemasok, jumlah, harga) FROM stdin;
\.
COPY public.tbltransaksi (notransaksi, tanggal, kodebarang, kodepemasok, jumlah, harga) FROM '$$PATH$$/5020.dat';

--
-- Name: tblbarang tblbarang_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tblbarang
    ADD CONSTRAINT tblbarang_pkey PRIMARY KEY (kodebarang);


--
-- Name: tblpemasok tblpemasok_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tblpemasok
    ADD CONSTRAINT tblpemasok_pkey PRIMARY KEY (kodepemasok);


--
-- Name: tbltransaksi tbltransaksi_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbltransaksi
    ADD CONSTRAINT tbltransaksi_pkey PRIMARY KEY (notransaksi);


--
-- Name: tbltransaksi tbltransaksi_kodebarang_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbltransaksi
    ADD CONSTRAINT tbltransaksi_kodebarang_fkey FOREIGN KEY (kodebarang) REFERENCES public.tblbarang(kodebarang) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tbltransaksi tbltransaksi_kodepemasok_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbltransaksi
    ADD CONSTRAINT tbltransaksi_kodepemasok_fkey FOREIGN KEY (kodepemasok) REFERENCES public.tblpemasok(kodepemasok) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

